const mongoose = require('mongoose')

const AppointmentSchema=new mongoose.Schema({
    nume: String,
    email: String ,
    vizitaTip: String ,
    telefon: String,
    data: Date,
    doctorTip: String,
    detalii: String

})

const AppointmentModel=mongoose.model("apointments", AppointmentSchema)
module.exports = AppointmentModel;
