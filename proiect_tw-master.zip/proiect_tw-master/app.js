const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const asyncHandler = require("express-async-handler");
const cors = require('cors');
const nodemailer = require('nodemailer');
require("dotenv").config()


const bcrypt = require("bcrypt");
const UserModel = require("./models/UserModel");
const AppointmentModel = require("./models/AppointmentModel")
const ContactModel = require("./models/ContactModel")

const app = express();

app.use(express.json());
app.use(cors())


mongoose.connect("mongodb+srv://Andrei:fWY-jJbcDBK8ZbN@localhost.wz2wft0.mongodb.net/UsersTw");

app.use(express.static('public'));

app.post('/Login.html', asyncHandler(async(req, res) => {
  const {username, password} = req.body;
  const user = await UserModel.findOne({username: username})
  
      if(user) {
        console.log("user:", user)
          
          if(await bcrypt.compare(password, user.password)){
              res.json({ status: 'Success'})
          }else{
              res.json("the password is incorrect")
          }
      }else{
          res.json("User not found")
      }
  
}))

app.post('/register.html', asyncHandler(async (req, res) => {
  const { username, email, password, passwordv } = req.body;

  if (password !== passwordv) {
    return res.json("The confirmation for password is incorrect");
  }

  if (!username || !email || !password || !passwordv) {
    return res.json("All fields must be completed");
  }

  const emailv = await UserModel.findOne({ email })

  if (emailv) {
    return res.json("Email already used");
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  console.log("Hashed Password: ", hashedPassword);

  const user = await UserModel.create({
    username,
    email,
    password: hashedPassword,
  })
    .then(users => res.json({ status: 'Success', message: 'Registration successful' }))
    .catch(err => res.json(err));
}));


app.post('/appointment.html', asyncHandler(async(req, res) => {
  const {nume, email, vizitaTip, telefon,  data, doctorTip, detalii} = req.body;

  if (!nume || !email || !vizitaTip || !telefon || !data || !doctorTip || !detalii) {
    return res.json("All fields must be completed");
  }

  const transporter = nodemailer.createTransport({
    service: "gmail",
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
      user: 'andrei.buglea02@e-uvt.ro',
      pass: process.env.X,
    },
  });

  const mailoptions = {
    from: {
      name:"qwe",
      address: 'andrei.buglea02@e-uvt.ro',
    }, 
    to: email, 
    subject: "Appointment", 
    text: "Appointment finished", 
  }
  


    const sendMail = async (transporter,mailoptions) => {
      try{
        await transporter.sendMail(mailoptions)
        console.log("Email send successfully")
      }catch(error){
        console.log(error)
      }
    }

    sendMail(transporter, mailoptions)
   
 
  const appointment = await AppointmentModel.create({
    nume, 
    email, 
    vizitaTip, 
    telefon,  
    data, 
    doctorTip, 
    detalii,
  })
  .then(appointments => res.json({status:"Success", message:"Appointment created successfully"}))
  .catch(err => res.json(err))

  
}))
app.post('/contact.html', asyncHandler(async(req, res) => {
  const {nume, email, telefon, mesaj} = req.body;

  if (!nume || !email || !telefon || !mesaj) {
    return res.json("All fields must be completed");
  }
  
  const appointment = await ContactModel.create({
    nume, 
    email, 
    telefon,  
    mesaj
  })
  .then(contacts => res.json({status:"Success", message:"Appointment created successfully"}))
  .catch(err => res.json(err))
  
}))

app.listen(3000, () => {
  console.log('Server is running at localhost:3000');
});
